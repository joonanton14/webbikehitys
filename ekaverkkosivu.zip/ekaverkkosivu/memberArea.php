<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
       
        form {
            position: absolute;
            top: 20px;
            right: 20px;
            
        }

        input[type="submit"] {
            background-color: black;
            color: blue;
            padding: 20px 30px;
            border: none;
            cursor: pointer;
            font-size: 135px;
        }
    </style>
</head>
<body>

<?php
session_start(); // tarvitaan funktio tiedoston alussa että sessio voi toimia

if (!isset($_SESSION["username"])) {
    
    header("Location: index.php"); 
    exit();
}

if (isset($_POST["logout"])) {
    session_destroy(); 
    header("Location: index.php"); 
    exit(); 
}
   
?>

    <div>
        

        <form method="post">
        <input type="submit" name="logout" value="Logout">
        </form>

        <!--Tervehdi tässä käyttäjää-->
        <!-- Tästä jatketaan itsenäisesti-->

        <h1>Welcome to the Member Area, <?php echo $_SESSION["username"]; ?></h1>
        

        
    </div>

</body>
</html>